import Portfolio from "@/components/portfolio";

export default function Home() {
  return (
    <div className="relative w-[90%]">
        <Portfolio />
    </div>
  );
}
